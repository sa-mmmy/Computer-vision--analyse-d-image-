import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
    //typescript: {
      //ignoreBuildErrors: true, // 👈 This skips type errors at build time
    //}
};


export default nextConfig;
