import Image from "next/image";
import "../components/map"
import App from "@/components/appWrapper";

export default function Home() {
  return (

    <div className="App">
     <App/>

    </div>

  );
}
